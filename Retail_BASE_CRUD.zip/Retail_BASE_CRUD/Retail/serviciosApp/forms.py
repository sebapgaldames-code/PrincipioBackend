from django import forms
from .models import Servicio, PrecioServicio


# Crea un formulario automáticamente basado en el modelo Servicio.
# Incluye todos los campos del modelo Servicio.
# Meta es una clase interna que define la configuración del formulario.
class ServicioForm(forms.ModelForm):
    class Meta:
        model = Servicio
        fields = '__all__'


# Formulario para crear un servicio junto con su precio.
# No incluye "servicio" porque ese servicio se acaba de crear.
class PrecioServicioCrearForm(forms.ModelForm):
    class Meta:
        model = PrecioServicio
        fields = ['precio', 'descuento', 'moneda', 'observacion']


# Crea un formulario automáticamente basado en el modelo PrecioServicio.
# Para la creación independiente de precios.
class PrecioServicioForm(forms.ModelForm):
    class Meta:
        model = PrecioServicio
        fields = '__all__'
