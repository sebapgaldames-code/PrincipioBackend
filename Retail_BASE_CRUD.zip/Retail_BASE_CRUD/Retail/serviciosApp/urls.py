from django.urls import path
from . import views

urlpatterns = [
    path('', views.servicios_list, name='listar_servicios'),
    path('crear/', views.servicio_crear),
    path('editar/<int:id>/', views.servicio_editar),
    path('eliminar/<int:id>/', views.servicio_eliminar),

    # AUTENTICACIÓN
    path('login/', views.login_servicios, name='login_servicios'),
    path('registro/', views.registro_usuario, name='registro_usuario'),
    path('logout/', views.cerrar_sesion, name='cerrar_sesion'),

    # PRECIOS
    path('precios/', views.precio_crear, name='precios'),
]
