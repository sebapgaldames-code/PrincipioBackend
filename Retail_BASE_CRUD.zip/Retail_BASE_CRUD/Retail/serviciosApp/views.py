from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.models import User

# NUEVO: Importar validación de contraseñas de Django
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError

from .models import Servicio, PrecioServicio
from .forms import ServicioForm, PrecioServicioForm

# LOGIN
def login_servicios(request):

    if request.user.is_authenticated:
        return redirect('listar_servicios')

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        usuario = authenticate(
            request,
            username=username,
            password=password
        )

        if usuario is not None:
            login(request, usuario)
            return redirect('listar_servicios')
        else:
            messages.error(request, 'Usuario o contraseña incorrectos.')

    # NUEVO: Mostrar el formulario real de inicio de sesión
    return render(request, 'serviciosApp/login_form.html')


# REGISTRO
def registro_usuario(request):

    if request.user.is_authenticated:
        return redirect('listar_servicios')

    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password')
        password2 = request.POST.get('password2')

        if not username or not password or not password2:
            messages.error(request, 'Todos los campos son obligatorios.')

        elif User.objects.filter(username=username).exists():
            messages.error(request, 'Este usuario ya existe.')

        elif password != password2:
            messages.error(request, 'Las contraseñas no coinciden.')

        else:

            # NUEVO: Validar contraseña según settings.py
            try:
                validate_password(password)

                # Crear usuario utilizando el sistema seguro de Django
                User.objects.create_user(
                    username=username,
                    password=password
                )

                messages.success(
                    request,
                    'Registro exitoso. Ahora puedes iniciar sesión.'
                )

                return redirect('login_servicios')

            # NUEVO: Mostrar errores de validación de contraseña
            except ValidationError as error:
                for mensaje in error.messages:
                    messages.error(request, mensaje)

    return render(request, 'serviciosApp/registro.html')

# CERRAR SESIÓN
@login_required(login_url='login_servicios')
def cerrar_sesion(request):

    if request.method == 'POST':
        logout(request)
        return redirect('login_servicios')

    return redirect('listar_servicios')

# LISTAR SERVICIOS
@login_required(login_url='login_servicios')
def servicios_list(request):

    servicios = Servicio.objects.all()

    return render(request, 'serviciosApp/listar.html', {
        'servicios': servicios
    })

# CREAR SERVICIO
@login_required(login_url='login_servicios')
def servicio_crear(request):

    form_servicio = ServicioForm(request.POST or None)
    form_precio = PrecioServicioForm(request.POST or None)

    if request.method == 'POST':

        if form_servicio.is_valid() and form_precio.is_valid():

            servicio = form_servicio.save()

            precio = form_precio.save(commit=False)
            precio.servicio = servicio
            precio.save()

            return redirect('/servicios/')

    return render(request, 'serviciosApp/crear.html', {
        'form_servicio': form_servicio,
        'form_precio': form_precio
    })

# CREAR PRECIO
@login_required(login_url='login_servicios')
def precio_crear(request):

    form = PrecioServicioForm(request.POST or None)

    if form.is_valid():
        form.save()
        return redirect('/servicios/')

    return render(request, 'serviciosApp/precio.html', {
        'form': form
    })

# EDITAR SERVICIO
@login_required(login_url='login_servicios')
def servicio_editar(request, id):

    servicio = get_object_or_404(Servicio, id=id)

    # IMPORTANTE: evitar error si no existe PrecioServicio
    precio, created = PrecioServicio.objects.get_or_create(
        servicio=servicio,
        defaults={
            'precio': 0,
            'descuento': 0,
            'moneda': 'CLP',
            'observacion': ''
        }
    )

    if request.method == 'POST':

        servicio.nombre = request.POST.get('nombre')
        servicio.descripcion = request.POST.get('descripcion')
        servicio.disponibilidad = request.POST.get('disponibilidad')
        servicio.save()

        precio.precio = request.POST.get('precio') or 0
        precio.descuento = request.POST.get('descuento') or 0
        precio.moneda = request.POST.get('moneda') or 'CLP'
        precio.observacion = request.POST.get('observacion') or ''
        precio.save()

        return redirect('listar_servicios')

    return render(request, 'serviciosApp/editar.html', {
        'servicio': servicio,
        'precio': precio
    })

# ELIMINAR SERVICIO
@login_required(login_url='login_servicios')
def servicio_eliminar(request, id):

    servicio = get_object_or_404(Servicio, id=id)

    if request.method == 'POST':
        servicio.delete()
        return redirect('listar_servicios')

    return render(request, 'serviciosApp/eliminar.html', {
        'servicio': servicio
    })
