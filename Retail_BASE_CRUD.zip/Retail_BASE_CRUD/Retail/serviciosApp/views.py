
from django.http import request
from urllib import request

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages

from .models import Servicio, PrecioServicio
from .forms import (
    ServicioForm,
    PrecioServicioForm,
    PrecioServicioCrearForm,
)

from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError


def login_servicios(request):

    if request.user.is_authenticated:
        return redirect('listar_servicios')

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('listar_servicios')
        else:
            messages.error(request, 'Nombre de usuario o contraseña incorrectos.')

    # Conserva la pantalla de acceso y navegación existente.
    return render(request, 'serviciosApp/login.html')

def registro_usuario(request):
    if request.user.is_authenticated:
        return redirect('listar_servicios')

    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password')
        password2= request.POST.get('password2')

        if not username or not password or not password2:
            messages.error(request, 'Todos los campos son obligatorios.')

        elif User.objects.filter(username=username).exists():
            messages.error(request, 'El nombre de usuario ya está en uso.')

        elif password != password2:
            messages.error(request, 'Las contraseñas no coinciden.')
            return render(request, 'serviciosApp/registro.html')

        else:
            try:
                validate_password(password)
                user = User.objects.create_user(username=username, password=password)
                user.save()
                messages.success(request, 'Usuario registrado exitosamente. Ahora puedes iniciar sesión.')
                return redirect('login_servicios')
            except ValidationError as e:
                messages.error(request, f'Error de validación de contraseña: {e.messages[0]}')

    return render(request, 'serviciosApp/registro.html')

@login_required
def cerrar_sesion(login_url='login_servicios'):

    if request.method == 'POST':
        logout(request)
        return redirect('login_servicios')

@login_required
def servicios_list(request):
    # Lista los servicios únicamente para usuarios autenticados.
    servicios = Servicio.objects.all()

    return render(
        request,
        'serviciosApp/listar.html',
        {'servicios': servicios},
    )


@login_required
def servicio_crear(request):
    # Formularios para crear un servicio y su precio.
    form_servicio = ServicioForm(request.POST or None)
    form_precio = PrecioServicioCrearForm(request.POST or None)

    if request.method == 'POST':
        if form_servicio.is_valid() and form_precio.is_valid():
            servicio = form_servicio.save()

            precio = form_precio.save(commit=False)
            precio.servicio = servicio
            precio.save()

            return redirect('listar_servicios')

    return render(
        request,
        'serviciosApp/crear.html',
        {
            'form_servicio': form_servicio,
            'form_precio': form_precio,
        },
    )


@login_required
def precio_crear(request):
    # Crear un precio mediante el formulario correspondiente.
    form = PrecioServicioForm(request.POST or None)

    if request.method == 'POST' and form.is_valid():
        form.save()
        return redirect('listar_servicios')

    return render(
        request,
        'serviciosApp/precio.html',
        {'form': form},
    )


@login_required
def servicio_editar(request, id):
    # Obtiene el servicio o devuelve un error 404.
    servicio = get_object_or_404(Servicio, id=id)

    # Obtiene el precio asociado o crea uno predeterminado.
    precio, created = PrecioServicio.objects.get_or_create(
        servicio=servicio,
        defaults={
            'precio': 0,
            'descuento': 0,
            'moneda': 'CLP',
            'observacion': '',
        },
    )

    if request.method == 'POST':
        servicio.nombre = request.POST.get('nombre')
        servicio.descripcion = request.POST.get('descripcion')
        servicio.disponibilidad = request.POST.get('disponibilidad')
        servicio.save()

        precio.precio = request.POST.get('precio') or 0
        precio.descuento = request.POST.get('descuento') or 0
        precio.moneda = request.POST.get('moneda') or 'CLP'
        precio.observacion = request.POST.get('observacion') or ''
        precio.save()

        return redirect('listar_servicios')

    return render(
        request,
        'serviciosApp/editar.html',
        {
            'servicio': servicio,
            'precio': precio,
        },
    )


@login_required
def servicio_eliminar(request, id):
    # Obtiene el servicio o devuelve un error 404.
    servicio = get_object_or_404(Servicio, id=id)

    # Elimina únicamente mediante una solicitud POST.
    if request.method == 'POST':
        servicio.delete()
        return redirect('listar_servicios')

    return render(
        request,
        'serviciosApp/eliminar.html',
        {'servicio': servicio},
    )


@login_required
def precios(request):
    # Lista los precios únicamente para usuarios autenticados.
    datos = PrecioServicio.objects.all()

    return render(
        request,
        'serviciosApp/precios.html',
        {'precios': datos},
    )
