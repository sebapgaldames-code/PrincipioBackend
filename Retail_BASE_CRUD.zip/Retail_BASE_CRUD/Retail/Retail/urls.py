
from django.contrib import admin
from django.urls import path, include
from django.shortcuts import render
from django.contrib.auth import views as auth_views


def menu(request):
    return render(request, 'menuApp/menu.html')


def informacion(request):
    return render(request, 'infoApp/index.html')


urlpatterns = [
    path('admin/', admin.site.urls),

    # Formulario de credenciales
    path(
        'credenciales/',
        auth_views.LoginView.as_view(
            template_name='serviciosApp/credenciales.html'
        ),
        name='credenciales',
    ),

    # Cierre de sesión
    path(
        'cerrar-sesion/',
        auth_views.LogoutView.as_view(),
        name='cerrar_sesion',
    ),

    # Menú principal
    path('', menu, name='menu'),

    # Página de información
    path('informacion/', informacion, name='informacion'),

    # Servicios y operaciones CRUD
    path('servicios/', include('serviciosApp.urls')),

    path('cuentas/login/', auth_views.LoginView.as_view(
        template_name='serviciosApp/login_form.html'), name='login'),
]
