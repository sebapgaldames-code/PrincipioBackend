from django.contrib import admin
from django.urls import path, include
from django.shortcuts import render
from django.contrib.auth import views as auth_views # NUEVO: Importar la vista de redirección de Django

def menu(request):
    return render(request, 'menuApp/menu.html')

def informacion(request):
    return render(request, 'infoApp/index.html')

urlpatterns = [
    path('admin/', admin.site.urls),

    path('', menu, name='menu'),
    path('informacion/', informacion),

    # RUTAS DEL CRUD DE SERVICIOS
    path('servicios/', include('serviciosApp.urls')),

    # NUEVO: Ruta de inicio de sesión utilizada por login_required
    path('cuentas/login/', auth_views.LoginView.as_view(
        template_name='serviciosApp/login_form.html'), name='login'),
    ]
