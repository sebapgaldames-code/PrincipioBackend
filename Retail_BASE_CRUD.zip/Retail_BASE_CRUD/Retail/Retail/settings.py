
"""
Django settings for Retail project.
Django 4.2.4
"""

from pathlib import Path
import os


# ==================================================
# RUTAS DEL PROYECTO
# ==================================================

BASE_DIR = Path(__file__).resolve().parent.parent

TEMPLATES_DIR = os.path.join(BASE_DIR, 'templates')


# ==================================================
# SEGURIDAD GENERAL
# ==================================================

SECRET_KEY = os.environ.get(
    'DJANGO_SECRET_KEY',
    'django-insecure-clave-solo-para-desarrollo-local',
)

DEBUG = True

ALLOWED_HOSTS = []


# ==================================================
# APLICACIONES INSTALADAS
# ==================================================

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    'menuApp',
    'infoApp',
    'serviciosApp',
]


# ==================================================
# MIDDLEWARE
# ==================================================

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]


# ==================================================
# URLS Y SERVIDOR
# ==================================================

ROOT_URLCONF = 'Retail.urls'

WSGI_APPLICATION = 'Retail.wsgi.application'


# ==================================================
# CONFIGURACIÓN DE PLANTILLAS
# ==================================================

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]


# ==================================================
# BASE DE DATOS
# ==================================================

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}


# ==================================================
# AUTENTICACIÓN
# ==================================================

LOGIN_URL = 'login_servicios'
LOGIN_REDIRECT_URL = '/servicios/'
LOGOUT_REDIRECT_URL = 'login'


# ==================================================
# VALIDACIÓN DE CONTRASEÑAS
# ==================================================

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': (
            'django.contrib.auth.password_validation.'
            'UserAttributeSimilarityValidator'
        ),
    },
    {
        'NAME': (
            'django.contrib.auth.password_validation.'
            'MinimumLengthValidator'
        ),
        'OPTIONS': {
            'min_length': 12,
        },
    },
    {
        'NAME': (
            'django.contrib.auth.password_validation.'
            'CommonPasswordValidator'
        ),
    },
    {
        'NAME': (
            'django.contrib.auth.password_validation.'
            'NumericPasswordValidator'
        ),
    },
]


# ==================================================
# SESIONES
# ==================================================

SESSION_ENGINE = 'django.contrib.sessions.backends.db'

# Duración de la sesión: 30 minutos
SESSION_COOKIE_AGE = 1800

# Renovar la expiración con cada solicitud
SESSION_SAVE_EVERY_REQUEST = True

# Expirar al cerrar el navegador
SESSION_EXPIRE_AT_BROWSER_CLOSE = True


# ==================================================
# SEGURIDAD DE COOKIES
# ==================================================

SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = 'Lax'

CSRF_COOKIE_SAMESITE = 'Lax'


# ==================================================
# PROTECCIÓN CONTRA CLICKJACKING
# ==================================================

X_FRAME_OPTIONS = 'DENY'


# ==================================================
# IDIOMA Y ZONA HORARIA
# ==================================================

LANGUAGE_CODE = 'es-cl'

TIME_ZONE = 'America/Santiago'

USE_I18N = True

USE_TZ = True


# ==================================================
# ARCHIVOS ESTÁTICOS
# ==================================================

STATIC_URL = 'static/'

STATICFILES_DIRS = [
    os.path.join(BASE_DIR, 'static'),
]


# ==================================================
# CLAVES PRIMARIAS
# ==================================================

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
