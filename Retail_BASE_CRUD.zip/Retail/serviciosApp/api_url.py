from django.urls import path
from . import api_views

urlpatterns = [
    path('', api_views.ApiInicioAPIView.as_view(), name='api_inicio'),
    path('servicios/', api_views.ServicioListCreateAPIView.as_view(), name='api_servicios'),
    path('servicios/<int:pk>/', api_views.ServicioDetailAPIView.as_view(), name='api_servicio_detalle'),
    path('precios/', api_views.PrecioServicioListAPIView.as_view(), name='api_precios'),
    path('precios/<int:pk>/', api_views.PrecioServicioDetailAPIView.as_view(), name='api_precio_detalle'),
]    