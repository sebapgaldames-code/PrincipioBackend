from rest_framework import serializers
from rest_framework import generics
from rest_framework.views import APIView
from rest_framework.response import Response

from .models import Servicio, PrecioServicio
from .serializers import ServicioSerializer, PrecioServicioSerializer

class ApiInicioAPIView(APIView):
    name = 'API RESTful EXpectacular'

    def get(self, request):
        return Response({
            'mensaje': 'Bienvenido a la API REST de Retail',
            'servicios': '/api/servicios/',
            'precios': '/api/precios/',
            'autenticacion': 'api-auth/login/',
        })

class ServicioListCreateAPIView(generics.ListCreateAPIView):
    queryset = Servicio.objects.all()
    serializer_class = ServicioSerializer


class ServicioDetailAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Servicio.objects.all()
    serializer_class = ServicioSerializer


class PrecioServicioListAPIView(generics.ListCreateAPIView):
    queryset = PrecioServicio.objects.all()
    serializer_class = PrecioServicioSerializer

class PrecioServicioDetailAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = PrecioServicio.objects.all()
    serializer_class = PrecioServicioSerializer