from rest_framework import serializers
from .models import Servicio, PrecioServicio

class ServicioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Servicio
        fields = '__all__'

class PrecioServicioSerializer(serializers.ModelSerializer):
    class Meta:
        model = PrecioServicio
        fields = '__all__'
