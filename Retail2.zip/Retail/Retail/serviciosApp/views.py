import json
from pathlib import Path
from django.http import HttpResponse
from django.shortcuts import render

def cargar_datos():
    archivo = Path(__file__).resolve().parent / "datos.json"
    with open(archivo, "r", encoding="utf-8") as archivo_json:
        return json.load(archivo_json)

def servicios(request):
    datos = cargar_datos()
    return render(request, "serviciosApp/servicios.html", {"servicios": datos})

def precios(request):
    pagina = '''
    <h1>Precios</h1>
    <ul>
        <li>Servicio 1: $150.000</li>
        <li>Servicio 2: $250.000</li>
        <li>Servicio 3: $100.000</li>
    </ul>
    <a href="/">Volver al menú</a>
    '''

    return HttpResponse(pagina)