from django.urls import path
from menuApp import views as vista

urlpatterns = [
    path('', vista.menu,name='menu'),
]