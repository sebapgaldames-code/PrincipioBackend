from django.urls import path
from . import views


# from django.urls import path
# from serviciosApp import views

urlpatterns = [
    path('', views.servicios_list, name='listar_servicios'),
    path('login/', views.login_servicios, name='login_servicios'),
    path('crear/', views.servicio_crear, name='crear_servicio'),
    path('editar/<int:id>/', views.servicio_editar, name='editar_servicio'),
    path('eliminar/<int:id>/', views.servicio_eliminar, name='eliminar_servicio'),
    path('catalogo/', views.servicios, name='servicios'),
    path('precios/', views.precios, name='precios'),
]
# urlpatterns = [
#     path('', views.servicios, name='servicios'),
#     path('precios/', views.precios, name='precios'),
# ]
