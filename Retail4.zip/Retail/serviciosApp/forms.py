from django import forms
from .models import Servicio, PrecioServicio

#crea un formulario automaticamente basado en modelo servicio
#incluye todos los campos del modelo servicio
#Meta es una clase interna que define metadatos para el formulario
class ServicioForm(forms.ModelForm):
    class Meta:
        model = Servicio
        fields = '__all__'

#Formulario para crear un servicio junto con su precio
#No incluye "servicio" porque ese servicio se acaba de crear
class precioServicioCrearForm(forms.ModelForm):
    class Meta:
        model = PrecioServicio
        fields = ['precio', 'descuento', 'moneda', 'observacion']

#Crea un formulario automaticamente basado en el modelo PrecioServicio
#Para la creacion independiente de precios
class PrecioServicioForm(forms.ModelForm):
    class Meta:
        model = PrecioServicio
        fields = '__all__'


