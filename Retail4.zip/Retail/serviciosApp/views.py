from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect, get_object_or_404
from .models import Servicio, PrecioServicio
from .forms import ServicioForm, precioServicioCrearForm

def login_servicios(request):
    error = None

    if request.method == "POST":
        usuario = authenticate(
            request,
            username=request.POST.get("username", ""),
            password=request.POST.get("password", ""),
        )
        if usuario is not None:
            login(request, usuario)
            return redirect("listar_servicios")

        error = "Usuario o contraseña incorrectos."

    return render(request, "serviciosApp/gestion/login.html", {"error": error})

def servicio_crear(request):
    form_servicio = ServicioForm(request.POST or None)
    form_precio = precioServicioCrearForm(request.POST or None)

    if request.method == "POST":
        if form_servicio.is_valid() and form_precio.is_valid():
            servicio = form_servicio.save()

            precio = form_precio.save(commit=False)
            precio.servicio = servicio
            precio.save()

            return redirect("/servicios/")

    return render(request, "serviciosApp/gestion/crear.html", {
        "form_servicio": form_servicio,
        "form_precio": form_precio
    })

def servicios_list(request):
    servicios = Servicio.objects.all()
    return render(request, "serviciosApp/gestion/listar.html", {"servicios": servicios})

def servicio_editar(request, id):
    servicio = get_object_or_404(Servicio, id=id)
    precio = PrecioServicio.objects.filter(servicio=servicio).first()
    form_servicio = ServicioForm(request.POST or None, instance=servicio)
    form_precio = precioServicioCrearForm(request.POST or None, instance=precio)

    if request.method == "POST":
        if form_servicio.is_valid() and form_precio.is_valid():
            servicio = form_servicio.save()
            precio = form_precio.save(commit=False)
            precio.servicio = servicio
            precio.save()
            return redirect("listar_servicios")

    return render(request, "serviciosApp/gestion/editar.html", {
        "servicio": servicio,
        "form_servicio": form_servicio,
        "form_precio": form_precio,
    })

def servicio_eliminar(request, id):
    servicio = get_object_or_404(Servicio, id=id)

    if request.method == "POST":
        servicio.delete()
        return redirect("listar_servicios")

    return render(request, "serviciosApp/gestion/eliminar.html", {"servicio": servicio})

def servicios(request):
    datos = Servicio.objects.all()
    return render(request, "serviciosApp/gestion/servicios.html", {"servicios": datos})

def precios(request):
    datos = PrecioServicio.objects.select_related("servicio").all()
    return render(request, "serviciosApp/gestion/precios.html", {"precios": datos})