"""
URL configuration for Retail project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.shortcuts import render 
# from infoApp import views as vista

# urlpatterns = [ 
#     path('admin/', admin.site.urls),
#     path('', include('menuApp.urls')),
#     path('informacion/', include('infoApp.urls')),
#     path('servicios/', include('serviciosApp.urls')),
# ]

def menu(request):
    return render(request, 'menuApp/menu.html')

def informacion(request):
    return render(request, 'infoApp/index.html')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', menu, name='menu'),
    path('informacion/', informacion),
    path('servicios/', include('serviciosApp.urls')),
]