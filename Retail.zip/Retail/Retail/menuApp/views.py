from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def menu(request):
    titulo = "<h1>Menú</h1>"
    logo = "<img serc = 'https://t4.ftcdn.net/jpg/09/08/04/71/360_F_908047115_yK9hRZrP2muTLTdoEn7HXj7ftogpZOus.jpg' width = '200px' height = '100px'>" 
    links = '''
    <ul>
        <li><a href="informacion/">Informacion</a></li>
        <li><a href="servicios/">Servicios</a></li>
        <li><a href="servicios/precios">Precios</a></li>
    </ul>
    '''

    pagina = titulo + logo + links
    return HttpResponse(pagina)