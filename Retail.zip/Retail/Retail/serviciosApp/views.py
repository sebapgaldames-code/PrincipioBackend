from pathlib import Path
from django.shortcuts import render
from django.http import HttpResponse
import json

# Create your views here.

def cargar_datos():
    archivo = Path(__file__).resolve().parent / 'datos.json'
    with open(archivo, 'r', encoding='utf-8') as archivo_json:
        return json.load(archivo_json)

def servicios(request):
    datos = cargar_datos()
    pagina = "<h1>Servicios</h1>"
    for servicio in datos:
        pagina += f"""
            <h2>{servicio['nombre']}</h2>
            <p><strong>ID:</strong> {servicio['id']}</p>
            <p><strong>Descripción:</strong> {servicio['descripcion']}</p>
            <p><strong>Precio:</strong> {servicio['precio']}</p>
            <p><strong>Disponibilidad:</strong> {servicio['disponibilidad']}</p>
            <hr>
        """

    pagina += "<br><a href ='/'>Volver al menu</a>"

    return HttpResponse(pagina)

def precios(request):
    pagina = """
    <h1>Precios de Servicios</h1>
    <ul>
        <li>Servicio 1: $5000</li>
        <li>Servicio 2: $20.000</li>
        <li>Servicio 3: $30.000</li>
    </ul>
    <br><a href ='/'>Volver al menu</a>
    """

    return HttpResponse(pagina)