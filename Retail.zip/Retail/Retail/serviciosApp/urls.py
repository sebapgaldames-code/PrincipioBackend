from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.servicios, name='servicios'),
    path("precios/", views.precios, name= "precios")
    
]
