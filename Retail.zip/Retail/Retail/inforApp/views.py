from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def informacion(request):
    titulo = "<h1>Quienes Somos</h1>"
    info = "<p>Aqui va informacion relevante</p>"
    volver = "<br><a href='../'>Volver al menu</a>"
    pagina = titulo + info + volver
    return HttpResponse(pagina)