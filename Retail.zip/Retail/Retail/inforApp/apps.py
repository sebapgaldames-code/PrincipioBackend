from django.apps import AppConfig


class InforappConfig(AppConfig):
    name = 'inforApp'
