from django.contrib import admin
from django.urls import path
from primeraApp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path("", views.inicio, name="inicio"),
    path("hora/", views.hora, name="hora"),
    path("acceder_inacap/", views.acceder_inacap, name="acceder_inacap"),
    path("wikidex/", views.wikidex, name="wikidex"),
]
