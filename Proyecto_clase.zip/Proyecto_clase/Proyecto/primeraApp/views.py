from django.shortcuts import render
from django.http import HttpResponse
import datetime

# Create your views here.

def inicio(request):
    return HttpResponse("<h1>Bienvenidos a mi primer proyecto en Django</h1>")


def hora(request):
    ahora = datetime.datetime.now()
    return HttpResponse(f"Fecha y hora actual: {ahora.strftime('%Y-%m-%d %H:%M:%S')}</h1>")

def acceder_inacap(request):
    return HttpResponse("<a href='https://www.inacap.cl/' target='_blank'>Acceder a Inacap</a>")

