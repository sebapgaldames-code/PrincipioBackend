from django.contrib import admin
from django.urls import path, include
from . import views # Apunta a todas las carpetas y archivos de la app, en este caso a views.py


urlpatterns = [
    path("", views.inicio, name="inicio"),
    path("wikidex/", views.wikidex, name="wikidex"),
    path("kurukuru/", views.kurukuru, name="kurukuru")
    ]
