from django.shortcuts import redirect, render
from django.http import HttpResponse
# Create your views here.

def inicio(request):
    return HttpResponse("<h1>Bienvenidos a mi segunda app en Django</h1>")

def wikidex(request):
    return HttpResponse("<a href='https://www.wikidex.net/wiki/Wikidex' target='_blank'>Acceder a Wikidex</a>")

def kurukuru(request):
    return redirect("https://www.youtube.com/watch?v=NY0ffyEu6uo")